package s.login;

import java.util.LinkedList;
import java.util.List;

public class DB {
    private static List<User> userList=new LinkedList<>();

   private  static DB instance=null;

    private DB(){}
    public  static DB getInstance() {
        if(instance==null){
            instance=new DB();
        }
            return instance;
    }
    public static void addUser(User user){
        userList.add(user);
    }
    public static List<User>   giveUsers(){
        return userList;
    }

}

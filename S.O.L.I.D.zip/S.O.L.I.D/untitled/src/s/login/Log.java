package s.login;

public class Log  {


    public void in(User user){
        if(!isHave(user)){
            DB.addUser(user);
            System.out.println("Awesome!");
        }
    }
    private boolean isHave(User user){
        return    DB.giveUsers().contains(user);
    }
}

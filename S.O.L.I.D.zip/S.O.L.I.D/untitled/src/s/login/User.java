package s.login;

public class User {
    private String  userName;
    private String phoneNum;
    private int parol;

    public User(String userName, String phoneNum, int parol) {
        this.userName = userName;
        this.phoneNum = phoneNum;
        this.parol = parol;
    }

    public String getUserName() {
        return userName;
    }

    public String getPhoneNum() {
        return phoneNum;
    }

    public int getParol() {
        return parol;
    }
}

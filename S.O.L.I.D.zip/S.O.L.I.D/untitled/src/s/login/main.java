package s.login;

public class main {
    public static void main(String[] args) {
        User user=new User("Islom","+99890",12345);
        User user1=new User("Islom","+99890",1234);
        Log log=new Log();
        log.in(user);
        log.in(user1);
        log.in(user1);
    }
}

package s.weddingHall;

public class DishWasher extends  Worker{

    public DishWasher(String workerName, int salary) {
        super(workerName, salary);
    }

    public  void washingDishes(){
        System.out.println("I can washing dishes");
    }


}

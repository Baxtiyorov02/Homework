package s.weddingHall;

public class Main {
    public static void main(String[] args) {
        DishWasher worker1=new DishWasher("Janze",100_000);
        worker1.washingDishes();
    }
}

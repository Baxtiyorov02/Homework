package s.weddingHall;

public class TheCook extends Worker {
    public TheCook(String workerName, int salary) {
        super(workerName, salary);
    }
    public void toCook(){
        System.out.println("I can  cook");
    }
    public void boilWater(){
        System.out.println("I can boiling water and make tea");
    }


}

package s.weddingHall;

public class Waiter extends  Worker{
      public Waiter(String workerName, int salary, String workerName1, int salary1) {
        super(workerName, salary);

    }

    public void servingGuests(){
        System.out.println("I can serving to guests");
    }
    public void foodDelivery(){
        System.out.println(" I can food delivery to guests ");
    }



}

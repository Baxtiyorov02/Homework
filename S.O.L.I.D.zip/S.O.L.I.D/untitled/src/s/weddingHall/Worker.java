package s.weddingHall;

public abstract class Worker {
   private String workerName;
    private int salary;

    public Worker(String workerName, int salary) {
        workerName = workerName;
        this.salary = salary;
    }

    public void setWorkerName(String workerName) {
        this.workerName=workerName;
    }

    public void setSalary(int salary) {
        this.workerName=workerName;

    }
    public String getWorkerName() {
        return workerName;
    }

    public int getSalary() {
        return salary;
    }
}

import java.util.Scanner;

public class Main {
    public static String sumTOText(String number){
        String t="";
        long sum= Long.parseLong(number);
        if(sum>1_000_000_000){
            t+=Speel((int) (sum/1_000_000_000))+ "milliard ";
            sum%=1_000_000_000;
        }
        if (sum>1_000_000){
            t+=Speel((int) (sum/1_000_000))+ "million ";
            sum%=1_000_000;
        }
        if (sum>1_000){
            t+=Speel((int) (sum/1_000))+ "ming ";
            sum%=1_000;
        }
        t+=Speel((int) sum)+ "sum ";
        return t;
    }
    public  static String tiyinToText(String number){
        String t="";
        int tiyin= Integer.parseInt(number);
        t=Speel(tiyin)+ "tiyin ";
        return t;
    }


    public static   String Speel(int n){
        StringBuilder text=new StringBuilder();
        switch (n/100){
            case 1 -> text.append( "bir yuz ");
            case 2 -> text.append( "ikki yuz ");
            case 3 -> text.append( "uch yuz ");
            case 4 -> text.append( "to`rt yuz ");
            case 5 -> text.append( "besh yuz ");
            case 6 -> text.append( "olti yuz ");
            case 7 -> text.append( "yetti yuz ");
            case 8 -> text.append( "sakkiz yuz ");
            case 9 -> text.append( "to`qqiz yuz ");
            default -> text.append( " ");

        }

        n=n%100;

        switch (n/10) {
            case 1 -> text.append("o`n ");
            case 2 -> text.append("yigirma ");
            case 3 -> text.append("o`ttiz ");
            case 4 -> text.append("qirq ");
            case 5 -> text.append("ellik ");
            case 6 -> text.append("oltmish ");
            case 7 -> text.append("yetmish ");
            case 8 -> text.append("sakson ");
            case 9 -> text.append("to`qson ");
            default -> text.append(" ");
        }
        n=n%10;
        switch (n) {
            case 1 -> text.append("bir ");
            case 2 -> text.append("ikki ");
            case 3 -> text.append("uch ");
            case 4 -> text.append("to`rt ");
            case 5 -> text.append("besh ");
            case 6 -> text.append("olti ");
            case 7 -> text.append("yetti ");
            case 8 -> text.append("sakkiz ");
            case 9 -> text.append("to`qqiz ");
            default -> text.append(" ");
        }
        return  text.toString();
    }


    public static void main(String[] args) {

        Scanner scanner=new Scanner(System.in);
        System.out.print("summani kiriring, raqamlarda :");
        String text= scanner.nextLine();
        String result="";
        String numbers[]=text.split("\\.");
        String sum=numbers[0];
        if(numbers.length==2){
            String tiyin=numbers[1];
            result=sumTOText(sum)+tiyinToText(tiyin);
        }
        else {
            result=sumTOText(sum);
        }
        System.out.println(result);
    }

}
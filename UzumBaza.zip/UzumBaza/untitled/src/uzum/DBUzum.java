package uzum;

import uzum.list.IslomList;

import java.util.ArrayList;

public class DBUzum {
    public DBUzum() {
    }

    public DBUzum(IslomList<User> users) {
        this.users = users;
    }

    ArrayList<User> arrayList = new ArrayList<>();
    private IslomList<User> users = new IslomList<>();
    private User user;

    public boolean isHave(int phoneNum) {
        for (int i = 0; i <users.size() ; i++) {
            User user1= (User) users.get(i);
            if (user1.getPhoneNumber()==phoneNum){
                return  true;
            }
        }
        return false;
    }
    public void addUser(int phoneNum,String password){
        User user1=new User(phoneNum,password);
        users.add(user1);
    }

    public  boolean isHaveCode(String code){
        for (int i = 0; i <users.size() ; i++) {
            User user1= (User) users.get(i);
            if(user1.getPassword().equals(code)){
                System.out.println("done!");
                return  true;
            }
        }
        return false;
    }
}


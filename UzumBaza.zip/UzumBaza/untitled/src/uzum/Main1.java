package uzum;

import uzum.list.IslomList;

import java.awt.desktop.UserSessionEvent;
import java.util.Scanner;

public class Main1 {
    public static void main(String[] args) {
        //forUzumDB();
        forCustomList();



    }

    private static void forCustomList() {

        IslomList<Integer>  list=new IslomList<>();
        list.add(15);
        list.add(56);
        list.add(588);
        list.add(5576);
        list.add(575756);
        list.add(5756);
        System.out.println(list.size());
        list.get(5);
        System.out.println(list.contains(56));
        list.remove(2);

        list.showList();


    }

    public  static void   welcome(){
        System.out.println("UzumBankga xush kelibsiz Kartangizni kiriring:");
    }
    public static void forUzumDB(){
        User user=new User(902461939,"1a2b3s4d");
        User user1=new User(902564616,"1a2b3s4d");
        User user2=new User(902564616,"1a2b3s4d");

        IslomList<User> userIslomList=new IslomList<>();

        userIslomList.add(user1);
        userIslomList.add(user2);
        userIslomList.add(user);

        DBUzum dbUzum=new DBUzum(userIslomList);
        Scanner scanner = new Scanner(System.in);

        System.out.println("Assalomu aleykum!");
        System.out.println("telefon raqamni kiriting:");
        System.out.print(" +998 ");
        int number= scanner.nextInt();

        if(!dbUzum.isHave(number)) {
            boolean useCode = true;
            int kod = 12345;
            System.out.println(kod);
            while (useCode) {
                System.out.println(number + " raqamga borgan kodni kiriting");
                if (scanner.nextInt() == kod) {
                    System.out.println("maxfiy kod kiriting raqam va harflrdan iborat bolsin!");
                    dbUzum.addUser(number, scanner.nextLine());
                    welcome();
                    useCode = false;
                } else {
                    System.out.println(" kod xato!");
                }

            }
        }
        else {
            System.out.println("bazada bu raqam mavjud!");
            System.out.println("maxfiy kodingizni kiriting!");
            String password= scanner.next();
            if (dbUzum.isHaveCode(password)){
                welcome();
            }
            else {
                System.out.println(" kod xato");
            }
        }

    }
}

package uzum;

public class User {
    private  int phoneNumber;
    private String password;

    public User(int phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public User(int phoneNumber, String password) {
        this.phoneNumber = phoneNumber;
        this.password = password;
    }

    public int getPhoneNumber() {
        return phoneNumber;
    }

    public String getPassword() {
        return password;
    }
}

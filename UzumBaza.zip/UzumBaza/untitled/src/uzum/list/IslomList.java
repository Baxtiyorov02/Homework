package uzum.list;

import java.util.Comparator;

public class IslomList<T> implements MyList {
    private  Object [] objects;
    private  int capacity=10;
    private  int size=0;

    public IslomList() {
        objects=new Object[capacity];
    }


    private  void Capasity(){
        capacity=((capacity*3)/2) + 1;
        Object[] newCusArr= new Object[capacity];
        for (int i = 0; i <size ; i++) {
            newCusArr[i]=objects[i];
        }
        objects=newCusArr;

    }



    @Override
    public boolean add(Object o) {
        if(size==capacity){
            Capasity();
        }
        objects[size++]=o;
        return true;
    }

    @Override
    public boolean add(int index, Object o) {
        Object [] newOb=new Object[size+1];


        return false;
    }

    @Override
    public int size() {
        return size;
    }


    @Override
    public void sort(Comparator comparator) {

    }


    @Override
    public int getCapasity() {
        return capacity;
    }

    @Override
    public Object get(int index) {
        return objects[index];
    }

    @Override
    public boolean remove(Object o) {
        int k=0;
        Object[] newOb=new Object[size-1];
        for (int i = 0; i <size ; i++) {
            if(objects[i].equals(o)){
                i++;
            }
            newOb[k++]=objects[i];
        }
        objects=newOb;
        return false;
    }

    @Override
    public Object remove(int index) {
        int k=0;
        Object[] newOb=new Object[size-1];
        for (int i = 0; i <size ; i++) {
            if(i==index){
                i++;
            }
            newOb[k++]=objects[i];
        }
        objects=newOb;
        return null;
    }

    @Override
    public boolean contains(Object o) {
        boolean isHave=false;
        for (int i = 0; i <size ; i++) {
            if (objects[i].equals(o)){
                isHave=true;
            }
        }
        return isHave;
    }

    @Override
    public void showList() {
        for (int i = 0; i < size; i++) {
            System.out.print(  ","+objects[i]);
        }
        System.out.println();

    }
}

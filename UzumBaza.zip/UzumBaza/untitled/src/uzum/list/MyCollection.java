package uzum.list;

public interface MyCollection<T> extends MyIterable {


}

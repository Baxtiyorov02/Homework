package uzum.list;

public interface MyIterable<T> {
}

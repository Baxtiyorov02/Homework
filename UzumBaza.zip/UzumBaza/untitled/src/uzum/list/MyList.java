package uzum.list;

import uzum.list.MyCollection;

import java.util.Comparator;

public interface MyList<T> extends MyCollection {
      boolean add(Object o);
      boolean add(int index,Object o);
      int size();
      void sort(Comparator comparator);
     int getCapasity();
      Object  get(int index);
      boolean remove(Object o);
      Object remove(int index);
      boolean contains(Object o);
      void showList();







}
